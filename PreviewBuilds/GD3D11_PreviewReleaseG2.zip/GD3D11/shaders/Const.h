
// Max number of nodes a skeletal can have
static const int NUM_MAX_NODES = 96;